"""
Simple Nosense Testing for Wisent-Guard

This package provides simple tools for testing evaluation robustness
by creating nonsensical versions of benchmark data.
"""