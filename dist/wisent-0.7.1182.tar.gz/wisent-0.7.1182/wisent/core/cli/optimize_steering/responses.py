"""Response generation for steering optimization - wraps wisent generate-responses CLI."""

from wisent.core.cli.generate_responses import execute_generate_responses

__all__ = ["execute_generate_responses"]
