"""Activation collection for steering optimization - wraps wisent get-activations CLI."""

from wisent.core.cli.get_activations import execute_get_activations

__all__ = ["execute_get_activations"]
