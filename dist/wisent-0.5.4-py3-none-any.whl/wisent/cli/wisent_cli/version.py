__all__ = ["APP_NAME", "APP_VERSION"]

APP_NAME = "Wisent Guard"
APP_VERSION = "0.1.0"
